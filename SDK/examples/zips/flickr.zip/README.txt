Flickr is a program that demonstrates the use of roSlideshow, 
roPosterScreen, RSS connection setup, XML processing, 
roPinEntryDialogue, roRegistry, and account linking.

A version of this is available in the Roku Channel Store for
users to add to their Roku player and start using now.

IMPORTANT: This application will not run as is. In order for 
you to use this version of the code, you need to replace the 
strings of 0's in main.brs with flickr developer api access 
keys.  There are comments in main.brs that explain how to 
get that information.

