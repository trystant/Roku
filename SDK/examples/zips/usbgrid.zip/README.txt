The usbgrid application shows how to use
roGridScreen inside the usb sample player.
Presently the multiple gridscreens do not
play well with audio of video player so
they still use the standard posterscreen.
