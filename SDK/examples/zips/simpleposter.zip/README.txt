The simpleposter application shows how to
use roPosterScreen. It shows a poster screen
with a filter banner of categories. When a 
new category is selected, the app receives 
events to refresh the content for the category.  
It's a minimalist application, designed to just
show how to set up this screen type.
